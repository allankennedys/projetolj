function getValue(){
    var value = document.getElementById('comprado').textContent="Em seu carrinho ✓";
}
